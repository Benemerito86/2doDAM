class GastoException(Exception):
    def __init__(self, mensaje="Gasto error"):
        super().__init__(self, mensaje)
